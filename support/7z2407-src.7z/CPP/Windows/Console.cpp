// Windows/Console.cpp

#include "StdAfx.h"

#include "Console.h"

namespace NWindows{
namespace NConsole{

}}

// LockedStream.h

#ifndef ZIP7_INC_LOCKED_STREAM_H
#define ZIP7_INC_LOCKED_STREAM_H

#endif
